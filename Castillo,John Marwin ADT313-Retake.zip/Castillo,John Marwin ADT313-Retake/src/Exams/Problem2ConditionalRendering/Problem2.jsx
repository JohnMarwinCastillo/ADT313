import Problemcomp1 from "../Problem1component/Problem1comp";
import {useState} from "react";

function Problem2() {
  const [count, setCount]= useState(0);
  
  const user = {
    name: 'Hedy Lamarr',
    imageUrl: 'https://i.imgur.com/yXOvdOSs.jpg',
    imageSize: 90,
  };

  
  function Profile() {
    return (
      <>
        <h1>{user.name}</h1>
        <img
          className='avatar'
          src={user.imageUrl}
          alt={'Photo of ' + user.name}
          style={{
            width: user.imageSize,
            height: user.imageSize,
          }}
        />
      </>
    );
  }

  function InitialContent() {
    return <h1>User profile is hidden.</h1>;
  }

  function handleClick() {
    setCount(count + 1);
  }    
  
  return (
    <>
      <div>
        <InitialContent />
        <button type='button' onClick={handleClick}>Show Profile</button>

        {count % 2 == 0 ? (
          <Profile />

        ) : (
          <InitialContent />
        )}
      </div>
    </>
  );
}

export default Problem2;
